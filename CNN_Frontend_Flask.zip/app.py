from flask import Flask, render_template, request
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import os

app = Flask(__name__)

# Load trained CNN model
model = load_model("model.h5")

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = ""
    if request.method == "POST":
        f = request.files["file"]
        filepath = os.path.join("uploads", f.filename)
        f.save(filepath)

        img = image.load_img(filepath, target_size=(100, 100))
        img_array = image.img_to_array(img)
        img_array = np.expand_dims(img_array, axis=0) / 255.0

        result = model.predict(img_array)

        if result[0][0] > 0.5:
            prediction = "Cat"
        else:
            prediction = "Dog"

    return render_template("index.html", prediction=prediction)

if __name__ == "__main__":
    app.run(debug=True)
